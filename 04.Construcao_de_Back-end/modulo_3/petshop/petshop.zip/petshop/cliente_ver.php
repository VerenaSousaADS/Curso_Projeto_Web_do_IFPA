<button id="btn_bscCliente">Preencher</button><br>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>NOME</th>
            <th>SOBRENOME</th>
            <th>CPF</th>
            <th>ENDERECO</th>
            <th>TELEFONE</th>
            <th>EMAIL</th>
        </tr>
    </thead>
    <tbody id="tblCliente">

    </tbody>
</table>